<!DOCTYPE html>
<html>
<body>

<h2>Produce</h2>

<p></p>

<script>
var Name = "produce";

var Colors = ["white", "Black", "red"];

var produce = "White";  // String written inside quotes
var produce = "black";  // String written inside quotes
var produce = "red";  // String written inside quotes
document.getElementById("display").innerHTML = produce;

</script>

</body>
</html>





